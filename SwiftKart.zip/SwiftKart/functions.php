<?php
function pdo_connect_mysql() {
      $DATABASE_HOST = '127.0.0.1:3308';
    $DATABASE_USER = 'root';
    $DATABASE_PASS = '';
    $DATABASE_NAME = 'product_web';
    $conn=new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME, $DATABASE_USER, $DATABASE_PASS);
    try {
    	return $conn;
    } catch (PDOException $exception) {
    	exit('Failed to connect to database!');
    }
}
function template_header() {
echo <<<EOT
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/productstyle.css">
<link rel="stylesheet" href="css/productsliststyle.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body> 
<div id="mySidenav" class="sidenav"><a href="home.php" style="text-decoration:none;"><span style="color: #fff;font-size: 30px;" class="logo">Swiftkart</span></a>
  <div>
    <form class="search" action="searchproduct.php"><input type="text" name="searchget" placeholder="search..." ></form>
      <!-- <a  style="font-size:30px;cursor:pointer" class="closebtn" onclick="closeNav()">&times;</a> -->
  <a href="index1.php">Products</a>
  <a href="about.html">About</a>
  <a href="contact.html">Contac Us</a>
  <a href="myorders.php" style="color: white;font-size: 18px;margin-top: -10px;" class="fa">&#xf290;</a>
  <a href="account.php" class="loginbtn">Account</a>
  </div>
</div>
<div class="resnav">
    <div style="margin-top: -10px;">
      <span style="color: #fff;font-size: 30px;margin-top: -30px;" class="logo"><a href="home.php" style="text-decoration:none;color:white;">Swiftkart</a></span>

      <span id="open-bar" style="cursor:pointer;color: #f1f1f1;margin-top: 0px;" onclick="openNav()">&#9776;</span>
   
      <span id="close-bar" style=" display: none;font-size:30px;color: white;cursor:pointer;margin-top: 0px;" class="closebtn" onclick="closeNav()">&times;</span>
  </div>
</div>
EOT;
}
function template_footer() {
echo <<<EOT
  

<div class="footer">
  <div class="col-1">
    <h3>Quick Links</h3>
    <a href="index1.php">Products</a>
    <a href="about.html">About</a>
    <a href="contact.html">Contact Us</a>
    <a href="account.php" >Account</a>
  </div>
  <div class="col-2">
    <h3>Subscribe to email alerts</h3>
    <form action="home.html">
  <center>    <input type="email" placeholder="Enter your email" required>
  <input type="submit" name="subscribe" value="Subscribe"></center>
    </form>
  </div>
  <div class="col-3">
  <h3>Social Links</h3>
  <a href="https://www.facebook.com/" class="fa">&#xf230;</a>
  <a href="https://linkedin.com/in/parth-miroliya-65a19122b" class="fa">&#xf08c;</a>
  <a href="https://www.youtube.com/" class="fa">&#xf16a;</a>
  <a href="https://www.instagram.com/parthmiroliya/" class="fa">&#xf16d;</a>
  </div>
  
  </div>
  <center style="color:white;background:black;margin-top:-30px;font-family: Audiowide , sans-serif;
  ">create by parth_mi</center>

</div>





  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("open-bar").style.display="none";
  document.getElementById("close-bar").style.display="";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("open-bar").style.display="";
  document.getElementById("close-bar").style.display="none";
}
function loadfun(){
 var load= document.getElementById("loaderweb");
 load.style.display='';
}
</script>
    </body>
</html>
EOT;
}
