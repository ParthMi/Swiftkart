<?php
session_start();
include "login/db_conn.php";
include "functions.php";
if (isset($_SESSION["user_name"])) {
    $username=$_SESSION['user_name'];
// $sql = "SELECT * FROM orders WHERE username='$username' ";
$sql = "SELECT orders.oid,orders.pid, orders.username,orders.address, products.id,products.name,products.price,products.img   
FROM orders
INNER JOIN products ON orders.pid=products.id WHERE username='$username' ";
$result = mysqli_query($conn, $sql);
?>

<?=template_header()?>
<?php
if(mysqli_num_rows($result) <= 0){
?><div>
<img src="images/orderlistempty.png" style="height:200px"><div>
<a href="index1.php"><button style="margin-left:130px; height:30px;border:none;background:black;color:white;width:100px;">Shop Now</button></a></div></div>
<?php
}
?>
<div style="background:#f2f2f2;border-radius:25px"><div style="margin-left:25px;margin-top:-30px;font-family: 'poppins', sans-serif;"><br><center><h2>My Orders</h2><hr style="width:80px;height:1px;color:black;background:black;"></center></div>
<?php
foreach ($conn->query($sql) as $row) {
    ?><div style="margin:20px;background:white;border-radius:25px">
    <table style=" font-family: 'poppins', sans-serif;"><tr>
    <td style="width: 160px;"><img class="pls-img" src="imgs/<?=$row['img']?>" width="150" height="auto"></td>
    <td style="width: auto;">
    Product Name :<span style="color: gray;"><?=$row['name']?></span>  <br>
    Price : <span style="color: gray;"><span class="fa"> &#xf156;</span><?=$row['price']?></span><br>
    For Product Details <a href="index1.php?page=product&id=<?=$row['pid']?>" style="text-decoration:none;font-size:19px;">Click here</a><br>
 Address :<span style="color: gray;"> <?=$row['address']?></span>
    </td></tr>      
    </table>
</div>
<?php
}
?></div>
</div>
<?=template_footer()?>
<?php
}
?>