<?php
include 'functions.php';
$DATABASE_HOST = '127.0.0.1:3308';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'product_web';
$conn=new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME, $DATABASE_USER, $DATABASE_PASS);

$searchget=$_GET['searchget'];
$stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE '%$searchget%';");
$stmt->execute();
// Fetch the products from the database and return the result as an Array
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?=template_header()?> <div class="rowstart">
            <div class="resnavsearch">
                <form action="searchproduct.php"><input type="text" placeholder="search..."></form>
            </div></div><br>
    <div class="container" style="color:black;margin-top:10px;margin-left:20px;">
       <div class="cards"> 
        <!-- badha product ne array mathi alg karya--> 
        <!-- foreach loop jevu kam kare-->
        <?php foreach ($products as $product): ?>
      
     <div class="card">
        <a  style="color:black;text-decoration:none;font-family: "Lucida Sans";" href="index1.php?page=product&id=<?=$product['id']?>" class="product">
            <img class="pls-img" src="imgs/<?=$product['img']?>" width="150" height="auto" alt="<?=$product['name']?>">
          <br>  <span class="pls-name"><?=$product['name']?></span><br>
            <span class="pls-price">
           <span class="fa"> &#xf156;</span> <?=$product['price']?>
               
            
        </a></div>
        <?php endforeach; ?>
        </div>
        
        </div>
        
    


<?=template_footer()?>