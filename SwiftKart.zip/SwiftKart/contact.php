

		<?php

$conn = mysqli_connect("localhost:3308", "root", "", "product_web");

// Check connection
if($conn === false){
    die("ERROR: Could not connect. "
        . mysqli_connect_error());
}

// Taking all 5 values from the form data(input)
$uname = $_REQUEST['uname'];
$email = $_REQUEST['email'];
$message = $_REQUEST['message'];


// Performing insert query execution
// here our table name is college
$sql = "INSERT INTO contact(uname,email,message) VALUES ('$uname',
    '$email','$message')";

if(mysqli_query($conn, $sql)){
    header("Location: home.php");


} else{
    echo "ERROR: Hush! Sorry $sql. "
        . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?>
