<?php
$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<?= template_header() ?><br><br>
<div  class="od1">  
    <div class="od1-div1"><img src="imgs/<?= $product['img'] ?>" class="odimg"></div>
    <div class="od1-div2"><br>
        <div style="color:silver; font-size:20px;margin-top:10px;">Product Details</div><br>
        <div><?= $product['name'] ?></div><br>
        <div><span class="fa">&#xf156;<span><?= $product['price'] ?></div>
        <div>For More Details <a href="index1.php?page=product&id=<?=$product['id']?>" style="text-decoration:none;font-size:19px;">Click here</a></div>
    </div>
</div>
<div class="odform"> <p style="font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif ;">Fill The Details.</p>
    <form action="index1.php?page=orderconformation&id=<?=$product['id']?>" method="POST">
   
    <input type="hidden" name="pid" value="<?=$product['id']?>">
   <div> <input type="text" class="textusername" value="<?=$_SESSION['user_name']?>" name="username" placeholder="Enter your Username"></div>
        <div><textarea  name="orderaddress" class="textareaform" placeholder="Enter your Address..."></textarea></div>
      <div>  <input type="submit" class="subbtn" name="submit" value="Place Order"></div>
    </form>
</div>
<?= template_footer() ?>
