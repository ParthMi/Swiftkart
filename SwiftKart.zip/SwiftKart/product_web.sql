-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:3308
-- Generation Time: Sep 05, 2022 at 06:46 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(100) NOT NULL,
  `uname` varchar(10000) NOT NULL,
  `email` varchar(10000) NOT NULL,
  `message` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `uname`, `email`, `message`) VALUES
(1, 'axitmi', 'axit@gmail.com', 'test message');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(120) NOT NULL,
  `pid` int(120) NOT NULL,
  `username` varchar(120) NOT NULL,
  `address` varchar(1100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`oid`, `pid`, `username`, `address`) VALUES
(1, 6, 'axitmi', 'B-24 shivmandir soc,surat,395010'),
(2, 5, 'axitmi', 'B-24 shivmandir soc,surat,395010'),
(3, 4, 'axitmi', 'surat,gujarat'),
(4, 5, 'parthmiroliya', 'b 24 surat'),
(5, 1, 'axitmi', 'gujarat'),
(6, 6, 'parthmiroliya', 'test ');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `desc` text NOT NULL,
  `specification` varchar(9000) NOT NULL,
  `price` int(255) NOT NULL,
  `img` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `desc`, `specification`, `price`, `img`, `date_added`) VALUES
(1, 'Noise Buds VS104 Truly Wireless earbuds', '<ul class="a-unordered-list a-vertical a-spacing-mini">   <li><span class="a-list-item"> Up to 30-hour playtime: Get set for a day full of music and then some more.  </span></li>  <li><span class="a-list-item"> Instacharge: Enjoy 150 minutes of playtime in just 10 minutes of charge.  </span></li>  <li><span class="a-list-item"> Tru Bass: Experience sound that hits the right note every single time via the 13mm speaker driver.  </span></li>  <li><span class="a-list-item"> Colourful ear tips: Colour your music the way you want and mix-match the ear tips with the buds to suit your style.  </span></li>  <li><span class="a-list-item"> Bluetooth v5.2: Lag-free and fuss-free connection is on the way.  </span></li>  <li><span class="a-list-item"> Hyper sync: The earbuds are ready to play in a matter of seconds, all thanks to the one-step syncing process.  </span></li>  <li><span class="a-list-item"> Touch control &amp; Voice assistant: You are in control always no matter how you want to get your work done.  </span></li>  </ul>', '<tbody><tr class="a-spacing-small po-brand"> <td class="a-span9">    <span class="a-size-base">Noise</span>   </td> </tr>  <tr class="a-spacing-small po-model_name"> <td class="a-span3"> <span class="a-size-base a-text-bold">Model Name</span> </td> <td class="a-span9">    <span class="a-size-base">Buds VS104</span>   </td> </tr>  <tr class="a-spacing-small po-color"> <td class="a-span3"> <span class="a-size-base a-text-bold">Colour</span> </td> <td class="a-span9">    <span class="a-size-base">Midnight Blue</span>   </td> </tr>  <tr class="a-spacing-small po-headphones_form_factor"> <td class="a-span3"> <span class="a-size-base a-text-bold">Form Factor</span> </td> <td class="a-span9">    <span class="a-size-base">In Ear</span>   </td> </tr>  <tr class="a-spacing-small po-connectivity_technology"> <td class="a-span3"> <span class="a-size-base a-text-bold">Connector Type</span> </td> <td class="a-span9">    <span class="a-size-base">Wireless</span>   </td> </tr>  </tbody>', 999, 'noise.jpg', '2019-03-13 17:55:22'),
(2, 'iqooz6 mobile', 'iQOO Z6 44W (Raven Black, 4GB RAM, 128GB Storage) | 44W FlashCharge + 5000mAh Battery | FHD+ AMOLED Display | in-Display Fingerprint', '<table class="a-normal a-spacing-micro">  <tbody><tr class="a-spacing-small po-brand"> <td class="a-span3"> <span class="a-size-base a-text-bold">Brand</span> </td> <td class="a-span9">    <span class="a-size-base">IQOO</span>   </td> </tr>  <tr class="a-spacing-small po-model_name"> <td class="a-span3"> <span class="a-size-base a-text-bold">Model Name</span> </td> <td class="a-span9">    <span class="a-size-base">IQOO Z6 44W</span>   </td> </tr>  <tr class="a-spacing-small po-wireless_provider"> <td class="a-span3"> <span class="a-size-base a-text-bold">Network Service Provider</span> </td> <td class="a-span9">    <span class="a-size-base">Unlocked for All Carriers</span>   </td> </tr>  <tr class="a-spacing-small po-operating_system"> <td class="a-span3"> <span class="a-size-base a-text-bold"> OS </span> </td> <td class="a-span9">    <span class="a-size-base">Funtouch OS 12 based on Android 12</span>   </td> </tr>  <tr class="a-spacing-small po-cellular_technology"> <td class="a-span3"> <span class="a-size-base a-text-bold">Cellular Technology</span> </td> <td class="a-span9">    <span class="a-size-base">LTE</span>   </td> </tr>  </tbody></table>', 14599, 'iqooz6.jpg', '2019-03-13 18:52:49'),
(3, 'boat earphone', 'The perfect way to add some style and stand out from the crowd with the boAt BassHeads 100 "Hawk" inspired earphones. Impedance 16Ω, Sensitivity (dB) 92db ±3db, Frequency Response 20Hz-20KHz\r\nThe stylish BassHeads 100 superior coated wired earphones are a definite fashion statement - wear your attitude with its wide variety of collection\r\nThe powerful 10mm dynamic driver with the speaker resistance of 16 ohm enables the earphone to deliver a punchy, rhythmic response to the most demanding tracks', '\r\nBrand	BoAt\r\nModel Name	BassHeads 100\r\nColour	Black\r\nForm Factor	In Ear\r\nConnector Type	Wired', 699, 'boat-bassheads.jpg', '2019-03-13 18:47:56'),
(4, 'Digital Camera', 'Water repellent Dust & dirt repellent Strong adhesion Antimicrobial Antifungal High SRI value – 105 Green technology', '', 70000, 'camara.jpg', '2019-03-13 17:42:04'),
(5, 'oneplus smart band', 'OnePlus Smart Band: 13 Exercise Modes, Blood Oxygen Saturation (SpO2), Heart Rate & Sleep Tracking, 5ATM+Water & Dust Resistant( Android & iOS Compatible)', '<table class="a-normal a-spacing-micro">  <tbody><tr class="a-spacing-small po-brand"> <td class="a-span3"> <span class="a-size-base a-text-bold">Brand</span> </td> <td class="a-span9">    <span class="a-size-base">OnePlus</span>   </td> </tr>  <tr class="a-spacing-small po-model_name"> <td class="a-span3"> <span class="a-size-base a-text-bold">Model Name</span> </td> <td class="a-span9">    <span class="a-size-base">W101IN</span>   </td> </tr>  <tr class="a-spacing-small po-style"> <td class="a-span3"> <span class="a-size-base a-text-bold">Style</span> </td> <td class="a-span9">    <span class="a-size-base">Smart Band</span>   </td> </tr>  <tr class="a-spacing-small po-color"> <td class="a-span3"> <span class="a-size-base a-text-bold">Colour</span> </td> <td class="a-span9">    <span class="a-size-base">Black</span>   </td> </tr>  <tr class="a-spacing-small po-display.size"> <td class="a-span3"> <span class="a-size-base a-text-bold">Screen Size</span> </td> <td class="a-span9">    <span class="a-size-base">1.1 Inches</span>   </td> </tr>  </tbody></table>', 1699, 'oneplussmartband.jpg', '2022-08-27 13:09:22'),
(6, 'Apple iPhone 13 (128GB) - Blue mobile phone', '12MP TrueDepth front camera with Night mode, 4K Dolby Vision HDR recording\nA15 Bionic chip for lightning-fast performance', '<table class="a-normal a-spacing-micro">  <tbody><tr class="a-spacing-small po-brand"> <td class="a-span3"> <span class="a-size-base a-text-bold">Brand</span> </td> <td class="a-span9">    <span class="a-size-base">Apple</span>   </td> </tr>  <tr class="a-spacing-small po-model_name"> <td class="a-span3"> <span class="a-size-base a-text-bold">Model Name</span> </td> <td class="a-span9">    <span class="a-size-base">IPhone</span>   </td> </tr>  <tr class="a-spacing-small po-wireless_provider"> <td class="a-span3"> <span class="a-size-base a-text-bold">Network Service Provider</span> </td> <td class="a-span9">    <span class="a-size-base">Unlocked for All Carriers</span>   </td> </tr>  <tr class="a-spacing-small po-operating_system"> <td class="a-span3"> <span class="a-size-base a-text-bold">Operating System</span> </td> <td class="a-span9">    <span class="a-size-base">IOS 14</span>   </td> </tr>  <tr class="a-spacing-small po-cellular_technology"> <td class="a-span3"> <span class="a-size-base a-text-bold">Cellular Technology</span> </td> <td class="a-span9">    <span class="a-size-base">GSM</span>   </td> </tr>  </tbody></table>', 69000, 'iphone13.jpg', '2022-08-27 18:48:27'),
(7, 'Noise ColorFit smart watch', 'Noise ColorFit Pulse Grand Smart Watch with 1.69"(4.2cm) HD Display, 60 Sports Modes, 150 Watch Faces, Fast Charge, Spo2, Stress, Sleep, Heart Rate Monitoring & IP68 Waterproof (Oilve Green)', '<table class="a-normal a-spacing-micro">  <tbody><tr class="a-spacing-small po-brand"> <td class="a-span3"> <span class="a-size-base a-text-bold">Brand</span> </td> <td class="a-span9">    <span class="a-size-base">Noise</span>   </td> </tr>  <tr class="a-spacing-small po-model_name"> <td class="a-span3"> <span class="a-size-base a-text-bold">Model Name</span> </td> <td class="a-span9">    <span class="a-size-base">ColorFit Grand</span>   </td> </tr>  <tr class="a-spacing-small po-style"> <td class="a-span3"> <span class="a-size-base a-text-bold">Style</span> </td> <td class="a-span9">    <span class="a-size-base">ColorFit Pulse Grand</span>   </td> </tr>  <tr class="a-spacing-small po-color"> <td class="a-span3"> <span class="a-size-base a-text-bold">Colour</span> </td> <td class="a-span9">    <span class="a-size-base">Olive Green</span>   </td> </tr>  <tr class="a-spacing-small po-display.size"> <td class="a-span3"> <span class="a-size-base a-text-bold">Screen Size</span> </td> <td class="a-span9">    <span class="a-size-base">1.69 Inches</span>   </td> </tr>  </tbody></table>', 1999, 'noisecolorfit.jpg', '2022-09-05 21:56:39'),
(8, 'boAt Bassheads 102  earphone', 'boAt Bassheads 102 in Ear Wired Earphones with Mic(Charcoal Black)', 'Brand	BoAt<br>\r\nModel Name	Bassheads<br>\r\nColour	Charcoal Black<br>\r\nForm Factor	In Ear<br>\r\nConnector Type	Wired<br>', 499, 'boat2.jpg', '2022-09-05 22:00:35'),
(9, 'pTron Bassbuds earphone', 'pTron Bassbuds Duo in-Ear Earbuds with 32Hrs Total Playtime, Bluetooth 5.1 Wireless Headphones, Stereo Audio, Touch Control TWS, Dual Mic, Type-C Fast Charging, IPX4 & Voice Assistance (Black)', '\r\nBrand	PTron<br>\r\nModel Name	Bassbuds Duo<br>\r\nColour	Black<br>\r\nForm Factor	In Ear<br>\r\nConnector Type	Wireless<br>', 899, 'ptron.jpg', '2022-09-05 22:03:29'),
(10, 'MI Power Bank', 'MI Power Bank 3i 20000mAh Lithium Polymer 18W Fast PD Charging | Input- Type C and Micro USB| Triple Output | Sandstone Black', '<table class="a-normal a-spacing-none a-spacing-top-base">  <tbody><tr class="a-spacing-none a-spacing-top-small po-connector_type"> <td class="a-span4"> <span class="a-size-small a-text-bold">Connector Type</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">USB, Micro USB</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-brand"> <td class="a-span4"> <span class="a-size-small a-text-bold">Brand</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">MI</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-battery.capacity"> <td class="a-span4"> <span class="a-size-small a-text-bold">Battery Capacity</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">20000 Milliampere Hour (mAh)</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-compatible_phone_models"> <td class="a-span4"> <span class="a-size-small a-text-bold">Compatible Phone Models</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Smartphones</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-color"> <td class="a-span4"> <span class="a-size-small a-text-bold">Colour</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Black</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-special_feature"> <td class="a-span4"> <span class="a-size-small a-text-bold">Special Feature</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Slim Fit, Travel, Universal</span>   </td> </tr>  </tbody></table>', 1999, 'powerbank1.jpg', '2022-09-05 22:05:34'),
(11, 'Boat Cabel', 'boAt Rugged v3 Extra Tough Unbreakable Braided Micro USB Cable 1.5 Meter (Black)', '<table class="a-normal a-spacing-none a-spacing-top-base">  <tbody><tr class="a-spacing-none a-spacing-top-small po-brand"> <td class="a-span4"> <span class="a-size-small a-text-bold">Brand</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">BoAt</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-connector_type"> <td class="a-span4"> <span class="a-size-small a-text-bold">Connector Type</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Micro USB</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-cable.type"> <td class="a-span4"> <span class="a-size-small a-text-bold">Cable Type</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">USB</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-compatible_devices"> <td class="a-span4"> <span class="a-size-small a-text-bold">Compatible Devices</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Compatible with all Micro USB enabled devices.</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-color"> <td class="a-span4"> <span class="a-size-small a-text-bold">Colour</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Black</span>   </td> </tr>  <tr class="a-spacing-none a-spacing-top-small po-connector_gender"> <td class="a-span4"> <span class="a-size-small a-text-bold">Connector Gender</span> </td> <td class="a-span6">    <span class="a-size-base a-color-tertiary">Male-to-Male</span>   </td> </tr>  </tbody></table>', 299, 'cabal1.jpg', '2022-09-05 22:07:35'),
(12, 'SanDisk Cruzer 32gb pendrive', 'SanDisk Cruzer Blade 32GB USB Flash Drive', '<table class="a-normal a-spacing-micro">  <tbody><tr class="a-spacing-small po-color"> <td class="a-span3"> <span class="a-size-base a-text-bold">Colour</span> </td> <td class="a-span9">    <span class="a-size-base">RED &amp; BLACK</span>   </td> </tr>  <tr class="a-spacing-small po-memory_storage_capacity"> <td class="a-span3"> <span class="a-size-base a-text-bold">Memory Storage Capacity</span> </td> <td class="a-span9">    <span class="a-size-base">32 GB</span>   </td> </tr>  <tr class="a-spacing-small po-brand"> <td class="a-span3"> <span class="a-size-base a-text-bold">Brand</span> </td> <td class="a-span9">    <span class="a-size-base">SanDisk</span>   </td> </tr>  <tr class="a-spacing-small po-hardware_interface"> <td class="a-span3"> <span class="a-size-base a-text-bold">Hardware Interface</span> </td> <td class="a-span9">    <span class="a-size-base">USB 2.0</span>   </td> </tr>  <tr class="a-spacing-small po-flash_memory.type"> <td class="a-span3"> <span class="a-size-base a-text-bold">Flash Memory Type</span> </td> <td class="a-span9">    <span class="a-size-base">Flash Drive</span>   </td> </tr>  </tbody></table>', 279, 'pendrive32.jpg', '2022-09-05 22:09:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(110) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `email`) VALUES
(1, 'parthmi', '72784', 'parthmi@gmail.com'),
(2, 'axitmi', '7bb62fc652665e464a50dbebdf05abe8', 'axit@gmail.com'),
(3, 'parthmiroliya', '7bb62fc652665e464a50dbebdf05abe8', 'parth@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(120) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
