<?php
if (isset($_GET['id'])) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$product) {
        echo 'Product does not exist!';
    }
} else {
    echo 'Product does not exist!';
}
?>
<?= template_header() ?>
<div class="rowstart">
    <div class="product-name">
        <button style="border: none;cursor:pointer;margin-left:10px;" class="fa" onclick="history.back()"> &#xf060;
            <b>BACK</b> </span>

    </div>



    <div class="product-img">
        <img src="imgs/<?= $product['img'] ?>">
    </div>

    <div class="pro-name">
        <h3><?= $product['name'] ?></h3>
        <div class="price-div">
            <span class="fa">&#xf156;<?= $product['price'] ?></span>
        </div>
        <div class="about-product">
            <h3 style="color:gray;">About the product</h3>
            <?= $product['desc'] ?>
        </div>
        <div>
            <h3 style="color:gray;"> Specifications</h3>
            <?= $product['specification'] ?>
        </div>
        <hr class="min600buybtn">
            <div class="buy-btn2">
              
        <a href="index1.php?page=orderdetails&id=<?= $product['id'] ?>" style="cursor:pointer;">  <button class="buy-btn1">BUY NOW</button> </a>
            </div>
       
    </div>




</div>
<a href="index1.php?page=orderdetails&id=<?= $product['id'] ?>" style="cursor: pointer;">
    <div class="buy-btn">
        <button class="buy-btn1"> BUY NOW</button>
    </div>
</a>
</div>
<?= template_footer() ?>