<?php
session_start();
include "login/db_conn.php";

if (isset($_SESSION["user_name"])) {

?>
    <!DOCTYPE html>
    <html>

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide|Sofia|Trirong">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
        <div id="mySidenav" class="sidenav"><span style="color: #fff;font-size: 30px;" class="logo">Swiftkart</span>
            <div>
                <form class="search" action="searchproduct.php"><input type="text" name="searchget" placeholder="search..."></form>
                <!-- <a  style="font-size:30px;cursor:pointer" class="closebtn" onclick="closeNav()">&times;</a> -->
                <a href="index1.php">Products</a>
                <a href="about.html">About</a>
                <a href="contact.html">Contac Us</a>
                <a href="myorders.php" style="color: white;font-size: 18px;margin-top: -10px;" class="fa">&#xf290;</a>
                <a href="account.php" class="loginbtn">Account</a>

              
            
            


        </div>
        </div>
        <div class="resnav">
            <div style="margin-top: -10px;">
                <span style="color: #fff;font-size: 30px;margin-top: -30px;" class="logo">Swiftkart</span>

                <span id="open-bar" style="cursor:pointer;color: #f1f1f1;margin-top: 0px;" onclick="openNav()">&#9776;</span>

                <span id="close-bar" style=" display: none;font-size:30px;color: white;cursor:pointer;margin-top: 0px;" class="closebtn" onclick="closeNav()">&times;</span>

            </div>
        </div>

        <div class="rowstart">
            <div class="resnavsearch">
                <form action="searchproduct.php"><input type="text" name="searchget" placeholder="search..."></form>
            </div>
            <div style="background:linear-gradient(to right,white 5%,#22b5d6 70%);width: 100%;height: 500px;">
                <div>.
                    <h3 class="welcome1">Welcome to Swiftkart...</h3><br>
                    <h3 class="welcome2">Fastest and easiest platform for shopping</h3>
                    <a href="about.html"><button class="welcome3">About Us</button></a>
                    <img src="welcome2.gif" class="welcome4" style="position: relative;margin-top: -250px;height: 400px;float: right;">
                </div>

                <div>

                </div>
            </div>
        </div>

        <a href="index1.php" style="text-decoration: none;"><div class="categories" style="width:auto;background:linear-gradient(to right,white 5%,#22b5d6 70%);width: 100%;">
            <div class="cat-item">
                <img src="images/headphone.jpg">
                <h4>
                    <center>Earphones</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="images/earphone.png">
                <h4>Headphones</h4>
            </div>
            <div class="cat-item">
                <img src="images/watch.png">
                <h4>
                    <center>SmartWatch</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="images/phone.png">
                <h4>
                    <center>Accessories</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="images/wirelessbuds.png">
                <h4>
                    <center>Wireless Earbuds</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="images/pendrive.jpg">
                <h4>
                    <center>Data Storage</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="imgs/fitband.png">
                <h4>
                    <center>Fitbands</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="images/cables.png">
                <h4>
                    <center>Cables</center>
                </h4>
            </div>
            <div class="cat-item">
                <img src="images/powerbank.png">
                <h4>
                    <center>Other</center>
                </h4>
            </div>
        </div></a>




        <div class="row">
            <div class="column">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRSviQwkVzCyeJKeWQkxHLRpgbo-FqKHIWYzQ&usqp=CAU" style="width:100%">

            </div>
            <div class="column">

                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQfxkejzoMlnhpGRqgCm8Rs5gMR7fgxofemA&usqp=CAU" style="width:100%">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTK1rU7qwxEroDJ0vtPuInqXUKSp3glwz7j7w&usqp=CAU" style="width:100%">

            </div>
            <div class="column">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJMAYAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAAEDBgcFBAj/xAA/EAABAgQEAgcEBwYHAAAAAAABAgMABAURBhIhMQdBE1FhcYGRoRQiMlIWQmJykrHwJIKiwdHhFTNDU2Oywv/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwDMkgdsSJHfAoJ019IkSTyV6QDpsOXpBD9aQySfm9IIE2+L0gPRIzKpSYQ+hIXlNlIUNFpIsUnsIJETVKVTLOIVLqK5R4Z5dw7lN7WP2knQ9o7o8YJtufKPXJToZbXLTTan5RxWZTYOVSFbZ0HYKt4KAAOwIAJOaXKPZwgONqTldaVs4nmk/mDyIBiSflQwW3pdZclHwSysjXTdKupQvr4HYxI9TluNOP055M4wgXXkTZxofbb3HeLp7YhkJtDOdiazOSL1ulSkaoI2cR1KHqCUnfQPMb6xGb/N6R6Z+VXJTHRLcStKkhbTqDdLqDspJ6j+dxyjxlXaYBlHX4h5RGo6/EfKCKhfcxEo3vvAdqeal5+mmsyLSGChxLc/Ko+FlxXwrQOTa+r6qrja0ckHvj1UGpN02ezTYU7ITDZl51oaFTStyPtA2UO0QqpIO0ufdk3nEuZCCh1I911BF0LHYpJB7L2gIAodvrDgjrMR3PX6Q4P60gJLj5lQrj5jEZV2H0hs3f5CAnadUy6h1l1xt1s3Q42SlST2EG4jo+1ylSOSpKRKzR0TPIRlbWf+ZI0H30gb+8DvHIKu/wAhAlV+RgO8yw4HVUGpDonSq8otwizTqtQArbI5oNNLlKuu/DdCm3FIcQpK0qKVJUCCCDYgx0JVZqlKcpzvvTUkhTspcXLjAF3Ge3KLrT2BY6oepuf4lT26sSC+0QzUDp8X+m6fvgWJ+ZP2hAcrNY/2iMq3/pBHlvEZv1wBAi2p9IsspLOV3Ccw4nWZoCQSq+q5RVzY/cUDb7J7IrIJ7/CLrwjrCKZi9uXmMvRVBosEq5K3SO42I8oCn3HzmFc20WfKLzO8Nq09iSflKbLIFPQ8SzMuuJS3kOoAtcmwNtvqmLDSeGuH5QKdrFXE2ppaUuIbcDaEKUbJSdb3JIG4vcaQGS3PzesL3rb6R9DU+mUSTMsmQoEumnvMKdXNONJR0Z0sFpWAq5udxpaKFxBpOHalJTVUwu9KKfp6k+3NyZBRlVcBWmlwQduV7wGb5ldcMSrrgCU3+NULT5jATSky/JTkvOyxJelnUuoF9yDex7Dt3Ex3qmZ7AuNHXpVkDollbTL3wusLNwCOY6t7FN+UVeY0YcIUdEHWNF41ISuqUWbAt7RIAX68pB/9wE6KVh7iNLuTmGXEUmvJBL9OdNm3D1i23eNOsX1jPKlT5ulzrsnUWHZaaaNltODUfyI7RpFj4V0tDmLpeqTCJpMlJXUt5pBypWR7oURsNz4Dri5cd36bNSFKmGFtOTXTFKXEEEqayknUcs2WAzLD1Hma/VmKbIqHSun4lbISN1HujesMYFouHkIcQwJmcSNZl/3lA88vJPhGS8Ip5ErjVtCsueZlnWWir59FD/qY5eK+JGLKjMPyj8yaaltam1y8p7hBBsQVfEduuA2nGeIaHS8qKpUpdrKnWXLqlE32u0nVXjpGcVjjClkBnDkhYIFkvTXupHc0nTzPhGSqUVElRJJNyTzgYDs17FNbr6yarUXn0XuGr5Wx3JGkdzhRU2pTE3+HThHsVVaVJvJO11fCe++njFKg2XVsvIdaUUONqCkKG4I1BgLNV5FdLqk3T30kOSzqmz2gbHxFjBUeTTU6tKSJd6H2h1LfSKFwm/O0WbiCpFVkqLimWSMlTl8kxbk8jQg+R/DFIW+60oOsKKHUEKQpO4IgNnp/C7DrFTaZqU49OMPNKs2Vls5xYnVPK19I4/HKakV1GjScopOaWYcBCTfIk5QkfwnyjOHMV4iddbcVUHQpsEJI0tcWMeQOuvOKemXFOvLN1LWbkmAtuEOIP0bknqc7LKW2VFaVo3JPIiKvOThqE/MzRQW0uuFaWwrRN+qIFNoUq5EOlKQNoCeWnH5Gbl52XJD0s4l1s9qTcR3eLUgyK1K16RT+w1qXTNItyXYZh+R7yYryr2sbxcqej6S8LqhTbZ52gve1MDmWVXKgP49OwQGaQoNYCTpr2wEAoUKFAaVw/cOIMF13DKjmmJce3yIJ1uPiA9PxmKeVZhqD5xNgOuHD2KqfUCqzKXcj+tgW1aKv3Xv4R28eUoUPFc9KNpHs61dOwQd0L19DceEBXLJ1uPWC000h8ybePXCI2/r/AHgGsLwBSLQiNYHbqgJc3Z6xYeHdZTR8Xya3z+yTf7JMhWoyr0BPcq3rFc8PWAcTdHV2iAmxjRF4fxLUKYoENsunor82zqg+RHjeOKT2RpPEFP0jwfQsXNgGYQj2GfsPrpvZR7zc/vCM1gFChQoBxvGoV1wYk4c0WvXCpumr9gnDfW2mQn+H8RjLo0PhFMtzr9WwtNrszWJVSWrn4XkC6SPC5/dEBViO0bwBNoldS5LuusPgpdaWULBGygbH1iNRvADmhj1wyucK+ggCv3QidOUDvD+cBd+Gq26tKVvB80tIRVGC7KlQ0S+gb+gP7sZu+04w+4y8gocbUUrSdwQbER2aZUH6RVZSpSt+mlXUuJHXY6jxFx4x2+LdNYYxE3WJAA0+tMJnWFJGmZQ98d99T96Ao8KFD3gGj2UeoPUmqSlQlyellnkupsbXsb27jtHlG0dmg4UruIVgUelzEwn/AHQnK2O9Zsn1gLTxRk2W8RN1WSsZKsy6JxpQ2uR7w/I+MVEK/V41DGOE6jR+FUgitOMLm6ZOWaLKiqzThtlJIGxI8hGW3tzgGWRDXhE3vDfnAEP1rBgfq8RptBiARH6vFzk0/SXhdPU8+/PYde9qY6zLqvnHgcx8ExTY7ODK/wDRnETM+62XZRaVMTbQF87St9OzQ+EBWpKQm6hMiXkJV+ZfOzTDZWvyGsaJhzgriCo5Xas41S2D9VZ6R0j7oNh4mNuwzN4WRTGzh16mtSixcJl1JR+Ib379YCu43wzRG1e31eWCwP8AKaX0iz4JvAcbDnCjC1DAdclDUJhOvSzllgdyfh9IujjktJSpcdW1Ly7SdVKIQlA/IRjWIuOJVmaw7Tio8n5w6d4QP5xmNexFXMSPdJWag9MJBulq9m09yRpAXzjDxBlMQBqiURfSyTLodfmBol1QuAE9YFyb8zaMzuTAJQEwXhAOTaB3OsK+0N3QEiYPlAaQ8AYMIi8CDBgwHnVLgm9oSZcDkI9EIwEQbA5Q+g5QUCYATvDHYw5EMYAb7QN4e+sDeAl5Q4hQoBQQ2hQoAxrAqJhQoASYcwoUA0CuGhQAGAMKFAf/2Q==" style="width:100%">

            </div>

        </div>
        </div>




        <div class="footer">
            <div class="col-1">
                <h3>Quick Links</h3>
                <a href="index1.php">Products</a>
                <a href="about.html">About</a>
                <a href="contact.html">Contact Us</a>
                <a href="account.php">Account</a>
            </div>
            <div class="col-2">
                <h3>Subscribe to email alerts</h3>
                <form action="home.html">
                    <center> <input type="email" placeholder="Enter your email" required>
                        <input type="submit" name="subscribe" value="Subscribe">
                    </center>
                </form>
            </div>
            <div class="col-3">
                <h3>Social Links</h3>
                <a href="#" class="fa">&#xf230;</a>
                <a href="#" class="fa">&#xf08c;</a>
                <a href="#" class="fa">&#xf16a;</a>
                <a href="#" class="fa">&#xf16d;</a>
            </div>

        </div>
        <center style="color:white;background:black;margin-top:-30px;font-family: Audiowide , sans-serif;
    ">create by parth_mi</center>









        <script>
            function openNav() {
                document.getElementById("mySidenav").style.width = "250px";
                document.getElementById("open-bar").style.display = "none";
                document.getElementById("close-bar").style.display = "";
            }

            function closeNav() {
                document.getElementById("mySidenav").style.width = "0";
                document.getElementById("open-bar").style.display = "";
                document.getElementById("close-bar").style.display = "none";
            }

            function loadfun() {
                var load = document.getElementById("loaderweb");
                load.style.display = '';
            }
        </script>

    </body>

    </html>

<?php
} else {
    header("location:login/index.html");
}
