<!-- 
$stmt1 = $conn->prepare("INSERT INTO orders (pid, username, address) VALUES (?,?,?)");
$stmt1->bind_param("iss", $_POST['pid'], $_POST['username'], $_POST['orderaddress']); -->

<?php
session_start();
// if(isset($_SESSION["username"]))
$sql = "INSERT INTO orders(pid,username,address) VALUES(:pid,:username,:address)";
$stmt = $pdo->prepare($sql);
$stmt->execute(['pid'=>$_POST['pid'],'username'=>$_POST['username'],'address'=>$_POST['orderaddress']]);
header('Location: home.html');
?>
<!-- else  
 {  
      header("location:login/index.html");  
 }   -->





