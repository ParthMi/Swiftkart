<?php
session_start();

include "functions.php";
include "login/db_conn.php";

if (isset($_SESSION["user_name"])) {

?>
<?=template_header()?>
</div>
<div style="margin-left:25px;margin-top:-30px;font-family: 'poppins', sans-serif;">
                <center><br>
                    <h2>My Account</h2>
                    <hr style="width:80px;height:1px;color:black;background:black;">
                </center>
            </div>
<center><br><div style="font-size:18px;font-family:'poppins', sans-serif;">
<center><img src="ring.png" height="100px"><div style="position: inherit;margin-top:-155px;font-size:40px;font-family: sans-serif; text-transform: uppercase; 
"><?php $fstchar = substr($_SESSION["user_name"], 0,1);
      echo "<h2>" . $fstchar . "</h2>";
    ?></div></center>
    Username  : <?=$_SESSION["user_name"]?><br><br>
    

    Email id : <?=$_SESSION["email"]?><br><br>
<a href="login/logout.php"><button style="border:2px solid black;border-radius:20px;cursor:pointer;height:40px;width:100px;background:white;font-size:20px;font-family: 'Audiowide', sans-serif;">Logout</button></a>
</center>
</div><center><div style="font-size: 18px;"><br><br>Contact to make changes to the account and for any information.<br> <a href="contact.html" style="color:gray;text-decoration:none;">Click here</a></div></center>
<?=template_footer()?>
<?php
} else {
    header("location:index.html");
}